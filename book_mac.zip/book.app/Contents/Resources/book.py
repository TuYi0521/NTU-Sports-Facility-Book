# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     book_UI
   Description :
   Author :       #TUYI#
   date：          4/12/2018
-------------------------------------------------
   Change Activity:
                   4/12/2018:
-------------------------------------------------
"""
__author__ = '#TUYI#'
import threading
import os

import tkinter as tk  # 导入tkinter模块
# import bookdev.bookwithGUI as bk
import datetime
import time
import calendar
import smtplib
from selenium import webdriver
from email.header import Header
from email.mime.text import MIMEText
from email.utils import parseaddr, formataddr
import tkinter.messagebox
from tkinter import ttk

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--disable-gpu')


#
def _format_addr(s):
    name, addr = parseaddr(s)
    return formataddr((Header(name, 'utf-8').encode(), addr))


def sendMail(msg, mail_server, port, sender, sender_passw, receiver):
    try:
        mail = smtplib.SMTP(mail_server, port)  # 使用SMTP()方法指向服务器（使用QQ邮箱服务器时，需改用 SMTP_SSL()方法）
        mail.login(sender, sender_passw)  # 请求服务器，登录帐号
        mail.sendmail(sender, receiver.split(","), msg.as_string())  # 发送邮件(给receiver传入列表时，表示群发)
        mail.quit()  # 断开连接
        print("email sent!")
    except:
        mail.quit()
        print("sending email failed!")


send_flag = False
mail_server = "smtp.qq.com"  # 发件人的 SMTP 服务器
port = "25"  # 服务端口

sender = "tuyi_ntu@qq.com"
sender_passw = "ipbywjvktreibhhf"
receiver = "tuyi0002@e.ntu.edu.sg"
"""
----------------------------------------------------------
    UI
-----------------------------------------------------------
"""
window = tk.Tk()  # 主窗口
window.title('NTU Sports Facility Book')  # 窗口标题
window.geometry('460x380')  # 窗口尺寸
# window.iconbitmap("C:/Users/#TUYI#/Desktop/1.ico")
buttonfrm = tk.Frame(window)  # 'button frame' is in Root window
buttonfrm.pack()

textframe = tk.Frame(window)  # text frame in Root window
textframe.pack(side='right')

window_btn = tk.Frame(window)
window_btn.pack(side='bottom')

varName = tk.StringVar()
varPwd = tk.StringVar()
identity = tk.StringVar()
sites = tk.StringVar()
identity.set("2")
sites.set("BS")

if os.path.exists("account.txt"):
    f = open("account.txt", "r")
    accountName = f.readline().strip()
    accountPass = f.readline().strip()
    accountID = f.readline().strip()
    accountSite = f.readline().strip()
    print(accountName)
    print(accountPass)
    print(accountID)
    print(accountSite)
    varName.set(accountName)
    varPwd.set(accountPass)
    identity.set(accountID)
    sites.set(accountSite)

# varPwd.set('GWUty.2016')
# varPwd.set('0806@961eiizzb')

# 创建标签
labelName = tk.Label(window, text='用户名:', justify=tk.RIGHT, width=80)
# 将标签放到窗口上
labelName.place(x=10, y=5, width=60, height=20)
# 创建文本框，同时设置关联的变量
entryName = tk.Entry(window, width=80, textvariable=varName)
entryName.place(x=80, y=5, width=100, height=20)

labelPwd = tk.Label(window, text='密 码:', justify=tk.RIGHT, width=80)
labelPwd.place(x=10, y=30, width=60, height=20)
# 创建密码文本框
entryPwd = tk.Entry(window, show='*', width=80, textvariable=varPwd)
# entryPwd = tk.Entry(window, width=80, textvariable=varPwd)
entryPwd.place(x=80, y=30, width=100, height=20)

##
l = tk.Label(window, bg='yellow', width=20, text='Who You Are')
l.place(x=30, y=65, width=80, height=20)


def print_selection():
    # l.config(text='you have selected ' + identity.get())  # identity.get()即获取到变量 identity 的值
    # 在这里设置变量的值
    print(identity.get())


r1 = tk.Radiobutton(window, text='Student', variable=identity, value='2', command=print_selection)
r1.place(x=30, y=90, width=80, height=20)
r2 = tk.Radiobutton(window, text='Staff', variable=identity, value='3', command=print_selection)
r2.place(x=30, y=115, width=80, height=20)



l2 = tk.Label(window, bg='yellow', width=20, text='Which Sports Court')
l2.place(x=30, y=145, width=120, height=20)

var3 = tk.StringVar()

# 创建Listbox
lb = tk.Listbox(window, listvariable=var3)
# 将var2的值赋给Listbox
lb.place(x=200, y=50, height=140, width=190)

print("lb")
print(lb.curselection())


def print_selection2():
    # l2.config(text='' + site)  # sites.get()即获取到变量 sites 的值
    print(sites.get())
    if sites.get() == 'BS':
        var3.set(('8:30-9:30', '9:30-10:30', '10:30-11:30', '11:30-12:30', '12:30-13:30', '13:30-14:30',
                  '14:30-15:30', '15:30-16:30', '16:30-17:30', '17:30-18:30', '18:30-19:30'))  # 为变量设置值
    elif sites.get() == 'BB':
        var3.set(('8:00-9:00', '10:00-11:00', '11:00-12:00', '12:00-13:00', '13:00-14:00',
                  '14:00-15:00', '15:00-16:00', '16:00-17:00', '17:00-18:00', '18:00-19:00',
                  '19:00-20:00', '20:00-21:00', '21:00-22:00'))  # 为变量设置值
    elif sites.get() == 'TN':
        var3.set(('7:30-8:15', '8:15-9:00', '9:00-9:45', '9:45-10:30', '10:30-11:15',
                  '11:15-12:00', '12:00-12:45', '12:45-13:30', '13:30-14:15', '14:15-15:00',
                  '15:00-15:45', '15:45-16:30', '16:30-17:15', '17:15-18:00',
                  '18:00-18:45', '18:45-19:30', '19:30-20:15', '20:15-21:00',
                  '21:00-21:45'))  # 为变量设置值


r1 = tk.Radiobutton(window, text='WAVE', variable=sites, value='BS', command=print_selection2)
r1.place(x=30, y=170, width=80, height=20)
r2 = tk.Radiobutton(window, text='North Hill', variable=sites, value='BB', command=print_selection2)
r2.place(x=30, y=195, width=80, height=20)
r3 = tk.Radiobutton(window, text='Table Tennis', variable=sites, value='TN', command=print_selection2)
r3.place(x=30, y=220, width=90, height=20)

wavetimetable = {'1': '9:30-10:30', '2': '10:30-11:30', '3': '11:30-12:30', '4': '12:30-13:30', '5': '13:30-14:30',
                 '6': '14:30-15:30', '7': '15:30-16:30', '8': '16:30-17:30', '9': '17:30-18:30', '10': '18:30-19:30'}

nhtimetable = {'1': '8:00-9:00', '2': '10:00-11:00', '3': '11:00-12:00', '4': '12:00-13:00', '5': '13:00-14:00',
               '6': '14:00-15:00', '7': '15:00-16:00', '8': '16:00-17:00', '9': '17:00-18:00', '10': '18:00-19:00',
               '11': '19:00-20:00', '12': '20:00-21:00', '13': '21:00-22:00'}

tennistimetable = {'1': '7:30-8:15', '2': '8:15-9:00', '3': '9:00-9:45', '4': '9:45-10:30', '5': '10:30-11:15',
                   '6': '11:15-12:00', '7': '12:00-12:45', '8': '12:45-13:30', '9': '13:30-14:15', '10': '14:15-15:00',
                   '11': '15:00-15:45', '12': '15:45-16:30', '13': '16:30-17:15', '14': '17:15-18:00',
                   '15': '18:00-18:45',
                   '16': '18:45-19:30', '17': '19:30-20:15', '18': '20:15-21:00', '19': '21:00-21:45'}

global t
global booktable


# t = 7
def settime(year, mon, d1, h, m, s):
    sched_time = datetime.datetime(year, mon, d1, h, m, s)
    return sched_time


def Setbooktable():
    value = lb.get(lb.curselection())

    if sites.get() == 'BS':
        timeindex = {v: k for k, v in wavetimetable.items()}
        j = 5
    elif sites.get() == 'BB':
        timeindex = {v: k for k, v in nhtimetable.items()}
        j = 6
    elif sites.get() == 'TN':
        timeindex = {v: k for k, v in tennistimetable.items()}
        j = 6
    t = timeindex[value]

    booktime = settime(int(entryYear.get()), int(entryMonth.get()), int(entryDay.get()), int(entryHour.get()),
                       int(entryMin.get()), int(entrySec.get()))
    time = booktime + datetime.timedelta(days=7)

    booktable = []
    for i in range(1, j, 1):
        v = '%s%s2%s0%d%02d-%s-%d%s' % (
            identity.get(), sites.get(), sites.get(), i, time.day, calendar.month_abbr[time.month], time.year, t)
        print('book table: ' + v)
        booktable.append(v)
    print("-------------------------------------")
    return booktable


labelDate = tk.Label(window, bg='yellow', text='Book Date:', justify=tk.RIGHT, width=80)
# 将标签放到窗口上
labelDate.place(x=220, y=5, width=150, height=20)

varYear = tk.StringVar()
varYear.set(datetime.datetime.now().year)
varMonth = tk.StringVar()
varMonth.set(datetime.datetime.now().month)
varDay = tk.StringVar()
varDay.set(datetime.datetime.now().day)
varHour = tk.StringVar()
varHour.set(datetime.datetime.now().hour)
varMin = tk.StringVar()
varMin.set(datetime.datetime.now().minute)
varSec = tk.StringVar()
varSec.set(datetime.datetime.now().second)

entryYear = tk.Entry(window, width=40, textvariable=varYear, justify=tk.RIGHT)
entryYear.place(x=200, y=25, width=40, height=20)

entryMonth = tk.Entry(window, width=40, textvariable=varMonth, justify=tk.RIGHT)
entryMonth.place(x=240, y=25, width=30, height=20)

entryDay = tk.Entry(window, width=40, textvariable=varDay, justify=tk.RIGHT)
entryDay.place(x=270, y=25, width=30, height=20)

entryHour = tk.Entry(window, width=40, textvariable=varHour, justify=tk.RIGHT)
entryHour.place(x=300, y=25, width=30, height=20)

entryMin = tk.Entry(window, width=40, textvariable=varMin, justify=tk.RIGHT)
entryMin.place(x=330, y=25, width=30, height=20)

entrySec = tk.Entry(window, width=40, textvariable=varSec, justify=tk.RIGHT)
entrySec.place(x=360, y=25, width=30, height=20)

def login(u, p, id, site, UI_flag):
    print("login begin")
    global d
    if UI_flag:
        d = webdriver.Chrome()
        
    else:
        d = webdriver.Chrome(chrome_options=chrome_options)
    
    d.get(
        'https://sso.wis.ntu.edu.sg/webexe88/owa/sso_redirect.asp?t=1&app=https://wis.ntu.edu.sg/pls/webexe88/srce_smain_s.Notice_O')
    d.find_element_by_name("UserName").send_keys(u)

    if id == '3':
        dd = d.find_element_by_name("Domain")
        dd.find_element_by_xpath("//option[@value='STAFF']").click()
        print("id: " + id)

    d.find_element_by_name("bOption").click()

    d.find_element_by_name("PIN").send_keys(p)

    d.find_element_by_name("bOption").click()

    if site == 'BS' or 'BB' or 'TN':
        if site == 'BS':
            i = 1
        elif site == 'BB':
            i = 0
        elif site == 'TN':
            i = 5
        while True:
            try:
                b = d.find_elements_by_name("p_info")
                b[i].click()
            except:
                d.refresh()
                continue
            print("finish login")
            # print("now it is %s" % datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

            f = open('account.txt', 'w')
            f.write(u+'\n')
            f.write(p+'\n')
            f.write(id+'\n')
            f.write(site)
            f.close()

            break
    else:
        pass

def confirm():
    confirm_thread = threading.Thread(target=login,args=(entryName.get(), entryPwd.get(), identity.get(), sites.get(), True))
    confirm_thread.setDaemon(True)
    confirm_thread.start()


# confmbutton = tk.Button(window, text="Confirm Info",
#                         command=lambda: login(entryName.get(), entryPwd.get(), identity.get(), sites.get(), True))
confmbutton = tk.Button(window, text="Confirm Info",
                        command=confirm)
confmbutton.place(x=30, y=250, width=80, height=20)

labelMail = tk.Label(window, text='邮箱:', justify=tk.RIGHT, width=80)
# 将标签放到窗口上
labelMail.place(x=200, y=220, width=40, height=20)
# 创建文本框，同时设置关联的变量
varMail = tk.StringVar()
varMail.set('tuyi0002@e.ntu.edu.sg')
entryMail = tk.Entry(window, width=300, textvariable=varMail)
entryMail.place(x=240, y=220, width=150, height=20)


def send():
    global send_flag
    send_flag = True
    print("send_flag: " + str(send_flag))
    global receiver
    receiver = entryMail.get()
    print("receiver:" + receiver)


ck1 = tk.Checkbutton(window, text='Send email after booking', command=send)
ck1.place(x=200, y=250, width=180, height=20)

# checkbutton = tk.Button(window, text="Check", command=lambda: login(entryName.get(), entryPwd.get(), identity.get(), sites.get()))
# checkbutton.place(x=240, y=240, width=80, height=20)

# print(type(entryYear.get()))
# print(int(entryYear.get()))

# booktime = bk.settime(int(entryYear.get()), int(entryMonth.get()), int(entryDay.get()), int(entryHour.get()), int(entryMin.get()), int(entrySec.get()))
# nextbooktime = booktime + datetime.timedelta(days=7)

ctLabel = tk.Label(text="当前时间")
ctLabel.place(x=10, y=280, width=50, height=20)

currentTimeLabel = tk.Label(text="")
currentTimeLabel.place(x=60, y=280, width=150, height=20)

tLabel = tk.Label(text="预约时间")
tLabel.place(x=10, y=300, width=50, height=20)

timeLabel = tk.Label(text="")
timeLabel.place(x=60, y=300, width=150, height=20)

countdownLabel = tk.Label(text="倒计时执行 Book:")
countdownLabel.place(x=220, y=280, width=100, height=20)

countdowntimeLabel = tk.Label(text="")
countdowntimeLabel.place(x=220, y=300, width=150, height=20)


def countdown(t):
    while True:
        if t > datetime.datetime.now():
            now=datetime.datetime.now()
            countdowntimeLabel.configure(text=sec2time((t - now).total_seconds()))
            time.sleep(1)

def run():
    booktime = settime(int(entryYear.get()), int(entryMonth.get()), int(entryDay.get()), int(entryHour.get()),
                       int(entryMin.get()), int(entrySec.get()))
    if len(entryName.get()) == 0 or len(entryPwd.get()) == 0:
        tk.messagebox.showinfo(title="Warning", message="you need to input your info")

    try:
        value = lb.get(lb.curselection())
        
    except:
        if len(lb.curselection()) == 0:
            tk.messagebox.showinfo(title='Warning', message='you need to select time')
        try:
            value = lb.get(lb.curselection())
            
        except:
            pass
   
    if sites.get() == 'BS':
        timeindex = {v: k for k, v in wavetimetable.items()}
        prio = [2, 3, 4, 1]
        j = 5
    elif sites.get() == 'BB':
        timeindex = {v: k for k, v in nhtimetable.items()}
        prio = [4, 5, 6, 3, 2, 1]
        j = 7
    elif sites.get() == 'TN':
        timeindex = {v: k for k, v in tennistimetable.items()}
        prio = [6, 4, 5, 3, 2, 1]
        j = 7

    t = timeindex[value]
    time = booktime + datetime.timedelta(days=7)
    booktable = []
    for i in range(1, j, 1):
        v = '%s%s2%s0%d%02d-%s-%d%s' % (
            identity.get(), sites.get(), sites.get(), i, time.day, calendar.month_abbr[time.month], time.year, t)
        print('book table: ' + v)
        booktable.append(v)
    print("-------------------------------------")
    # update_clock()
    # timeLabel.configure(text=booktime.strftime('%Y-%m-%d %H:%M:%S'))
    tk.messagebox.showinfo(title="Hi", message="Book start!")
    # initialization
    usr = entryName.get()
    pwd = entryPwd.get()
    global index

    index = [i - 1 for i in prio]

    while True:
        now = datetime.datetime.now()
        # print("now it is: %s" % (now.strftime('%Y-%m-%d %H:%M:%S')))
        # 即时Book
        #
        timeLabel.configure(text=booktime.strftime('%Y-%m-%d %H:%M:%S'))
        # end
        if booktime < now:
            # booktime = now
            # booktime = now + datetime.timedelta(seconds=10)

            login(usr, pwd, identity.get(), sites.get(), True)
            # print("fresh begin it is: %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            # d.refresh()
            # print("fresh end it is: %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

            flag = False

            for i in index:
                # print("i: "+str(i+1))
                v = booktable[i]
                # print("now it is: %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                try:
                    button1 = d.find_element_by_xpath("//input[@value='%s']" % v)
                    button1.click()
                    # print("button1 it is: %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                    try:
                        alert = d.switch_to.alert
                        txt = alert.text
                        if txt == 'You have an outstanding advance booking. You may book again after the outstanding advance session has lapsed.':
                            alert.accept()
                            # print(txt)
                            mail_msg = '''Dear %s,
%s
Sorry,
Tu Yi
''' % (usr, txt)
                            print(mail_msg)
                            tk.messagebox.showinfo(title='Warning', message=mail_msg)
                            break
                        else:
                            alert.accept()
                            continue
                    except:
                        button2 = d.find_element_by_xpath("//input[@value='Confirm']")
                        button2.click()
                        confirm_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        print("book confirm it is %s" % confirm_time)
                        flag = True

                        break
                except Exception as e:
                    continue
            print("send_flag here: " + str(send_flag))
            if flag:
                if send_flag:
                    # send mail

                    mail_msg = '''Dear %s,
Kindly inform that bookings for next week is successful. Good night!                
Best regards,
Tu Yi
''' % usr
                    print(mail_msg)

                    msg = MIMEText(mail_msg, "plain",
                                   "utf-8")  # 邮件内容（正文）  需要发送HTML文件时，plain 改为 html 即可!
                    msg['From'] = _format_addr("TUYI" + ' <%s>' % sender)
                    msg['To'] = _format_addr("SPMS-NH" + ' <%s>' % receiver)
                    msg['Subject'] = Header("Badminton North Hill", 'utf-8').encode()
                    msg['Subject'] = "Badminton"
                    sendMail(msg, mail_server, port, sender, sender_passw, entryMail.get())
                    print("here")
                # end
            else:
                print('there is no position')
                mail_msg='Book failed, please check by yourself'
            print("book over here")
            tk.messagebox.showinfo(title='Hi', message=mail_msg)
            break

            # time.sleep(100)
            # nextbooktime = booktime + datetime.timedelta(days=7)
            # booktime = nextbooktime
            # print("next book time is: %s" % booktime.strftime('%Y-%m-%d %H:%M:%S'))

        # 定期book
        else:
            if datetime.datetime.now() + datetime.timedelta(minutes=5) > booktime:
                print("book time is: %s" % (booktime.strftime('%Y-%m-%d %H:%M:%S')))

                # book on time
                while True:
                    now = datetime.datetime.now()
                    # countdowntimeLabel.configure(
                    #     text=sec2time((booktime - now).total_seconds()))
                    # current_t = now.strftime('%Y-%m-%d %H:%M:%S')
                    # print("It's " + current_t)

                    if booktime < (now + datetime.timedelta(seconds=1)) < (booktime + datetime.timedelta(seconds=1)):
                        print("fresh begin it is: %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                        d.refresh()
                        print("fresh end it is: %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

                    if booktime < now:
                        print("book begin it is: %s" % (now.strftime('%Y-%m-%d %H:%M:%S')))
                        flag = False

                        for i in index:
                            # print("i: "+str(i+1))
                            v = booktable[i]
                            # print("now it is: %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                            try:
                                button1 = d.find_element_by_xpath("//input[@value='%s']" % v)
                                button1.click()
                                # print("button1 it is: %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                                try:
                                    alert = d.switch_to.alert
                                    txt = alert.text
                                    if txt == 'You have an outstanding advance booking. You may book again after the outstanding advance session has lapsed.':
                                        alert.accept()
                                        # print(txt)
                                        mail_msg = '''Dear %s,
                        %s
                        Best wishes,
                        Tu Yi
                        ''' % (usr, txt)
                                        print(mail_msg)
                                        tk.messagebox.showinfo(title='Warning', message=mail_msg)
                                        break
                                    else:
                                        alert.accept()
                                        continue
                                except:
                                    button2 = d.find_element_by_xpath("//input[@value='Confirm']")
                                    button2.click()
                                    confirm_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                                    print("confirm it is %s" % confirm_time)
                                    flag = True
                                    # send mail
                                    if send_flag:
                                        mail_msg = '''Dear %s,
    Kindly inform that bookings for next week is successful. Good night!                
    Best regards,
    Tu Yi
    ''' % usr
                                        print(mail_msg)

                                        msg = MIMEText(mail_msg, "plain",
                                                       "utf-8")  # 邮件内容（正文）  需要发送HTML文件时，plain 改为 html 即可!
                                        msg['From'] = _format_addr("TUYI" + ' <%s>' % sender)
                                        msg['To'] = _format_addr("SPMS-NH" + ' <%s>' % receiver)
                                        msg['Subject'] = Header("Badminton North Hill", 'utf-8').encode()
                                        msg['Subject'] = "Badminton"
                                        sendMail(msg, mail_server, port, sender, sender_passw, entryMail.get())
                                    # end
                                    break
                            except Exception as e:
                                continue
                        if not flag:
                            print('there is no position')
                            mail_msg='Book failed, please check by yourself'
                            
                        print("book end it is: %s" % (now.strftime('%Y-%m-%d %H:%M:%S')))
                        break

                    if booktime < (now + datetime.timedelta(seconds=20)) < (booktime + datetime.timedelta(seconds=2)):
                        # print("current url:   "+d.current_url)
                        try:
                            login(usr, pwd, identity.get(), sites.get(), False)
                        except:
                            print("login error")
                    # time.sleep(1)
                #

                print("book on time over")
                tk.messagebox.showinfo(title='Notice', message=mail_msg)
                break
                # nextbooktime = booktime + datetime.timedelta(days=7)
                # booktime = nextbooktime
                # print("next book time is: %s" % booktime.strftime('%Y-%m-%d %H:%M:%S'))

        # time.sleep(1)


def book():
    thread = threading.Thread(target=run)
    thread.setDaemon(True)
    thread.start()
    
    booktime = settime(int(entryYear.get()), int(entryMonth.get()), int(entryDay.get()),
                                      int(entryHour.get()), int(entryMin.get()), int(entrySec.get()))
    countdown_thread = threading.Thread(target=countdown, args=[booktime])
    countdown_thread.setDaemon(True)
    countdown_thread.start()


# run & exit button
runbutton = tk.Button(window, text="BOOK", command=book)
# runbutton = tk.Button(window, text="BOOK", command=lambda: run(entryName.get(), entryPwd.get()))
runbutton.place(x=120, y=340, width=80, height=20)
exitbutton = tk.Button(window, text="EXIT", command=window.quit)
exitbutton.place(x=280, y=340, width=80, height=20)

labelGit = tk.Label(window_btn, text='Copyright: https://github.com/TuYi0521', justify=tk.RIGHT, width=200)
# 将标签放到窗口上
labelGit.pack(side='bottom')


def sec2time(sec):
    days = int(sec / (24 * 60 * 60))
    hours = int(sec % (24 * 60 * 60) / (60 * 60))
    minutes = int(int(sec % (24 * 60 * 60) % (60 * 60)) / 60)
    seconds = int(int(sec % (24 * 60 * 60) % (60 * 60)) % 60)

    s = "%s:%s:%s:%s" % (days, hours, minutes, seconds)
    return s


def update_clock():
    if (len(entryYear.get()) and len(entryMonth.get()) and len(entryDay.get()) and len(entryHour.get()) and len(
            entryMin.get()) and len(entrySec.get())) != 0:
        try:
            booktimedisplay = settime(int(entryYear.get()), int(entryMonth.get()), int(entryDay.get()),
                                      int(entryHour.get()), int(entryMin.get()), int(entrySec.get()))
            timeLabel.configure(text=booktimedisplay.strftime('%Y-%m-%d %H:%M:%S'))
            # if booktimedisplay > datetime.datetime.now():
            #     countdowntimeLabel.configure(text=sec2time((booktimedisplay - datetime.datetime.now()).total_seconds()))
            # else:
            #     countdowntimeLabel.configure(text="")

        except Exception as e:
            print("error: " + str(e))
            tk.messagebox.showinfo(title='Error', message='please input correct date\n' + str(e))

            varYear.set(datetime.datetime.now().year)
            varMonth.set(datetime.datetime.now().month)
            varDay.set(datetime.datetime.now().day)
            varHour.set(datetime.datetime.now().hour)
            varMin.set(datetime.datetime.now().minute)
            varSec.set(datetime.datetime.now().second)

            booktimedisplay = settime(int(entryYear.get()), int(entryMonth.get()), int(entryDay.get()),
                                      int(entryHour.get()), int(entryMin.get()), int(entrySec.get()))
            timeLabel.configure(text=booktimedisplay.strftime('%Y-%m-%d %H:%M:%S'))
            # if booktimedisplay > datetime.datetime.now():
            #     countdowntimeLabel.configure(text=sec2time((booktimedisplay - datetime.datetime.now()).total_seconds()))

    currentTimeLabel.configure(text=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    window.after(1000, update_clock)


if __name__ == '__main__':
    update_clock()
    window.mainloop()